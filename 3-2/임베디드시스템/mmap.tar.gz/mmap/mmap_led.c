01n  Memory Mapped LED Control Example
FILE : ap_lefnc  
AUTH : Huins, Inc
HOME : www.huins.com
DATE : 2011.10.17 23:55
MENT : Patch ap_l error 
*/

#include <stdio.h>*/

#include <l*

#ine.17 23:55
MENT : Patch ap_l er): ap_lefnc  
AUTHtfringp_lefnc  
AUTH <sn*

#ine.17 23:5fcntl

#ine.17 23:5ctype

#ine.17 23:5termiosp_lefnc  
AUTHtys/ioctl

#ine.17 23:5tys/typesp_lefnc  
AUTHtys/clunp_lefnc  
AUTHtignal

#i
#definee
FI_MAP_SIZE 0x1125			D Coxaming Size .h>#definee
FI_PHY_ADDR 0x074 0125		D C
FILphysical address .h>#definee
FI_OFFSET 0x16              D C
FILOffset frtl*mcal adm    ne
FILOffse(.17 23:55
|mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm fmmmmmmmmmmmmmmmmm4	;

unmmmmne.int val[] = {mmmm0,mmmfe,mmmfd,mmmfb,mmmf7,mmmef,mmmdf,mmmbf,mmm7f };

// UsmmmmExi8 *mmmmmm
nt vqu8 *= 0;mmmmmmqu8 _mmmmmm(nt vmmma (Exi8 E	/tf1;
}


nt vmain (nt vargc, chFIL*argv[]a (Exnt vfd;
	e
Ftic nmmmmne.ichFILmmm

/mmmmmmmme.iDevice Openmmmm	fd/tfopen( "/dev/mem", O_RDWR | O_SYNC );
	if (fd/t= -1a (ExipAP_SI("/dev/mem");
		return -1;
	}
/mmmmmctype
mmmmmmmmmmm	mmmmm4	;/tf
FI_((mmmmmm),mmmmmmmmmmmmmm, PROT_WRITE|PROT_READ, mmmmmHARED, d,mmmmmmmmmmmm fm;
	if (mmmmm4	;/t= NULLa (ExipAP_SI("
FI_()");
		return -1;
	}
/mmmmSmmmmm S
FItmmmm	mmmmmm(SIGINT,mqu8 _mmmmmm );
	pal tf("\nPmmmmmFILrl+c> tomqu8 .\n\n");
/mm/3:5termioro
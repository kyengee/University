﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
    public static Inventory instance = null;
    GameObject inventory_window = null;
    GameObject status_window = null;
    const int inventory_max = 19;
    int current_count;

    Sprite defaultImage = null;
    bool window_show;
    public List<GameObject> slots;
    int equipment_count;
    int consume_count;
    int etc_count;


    //클래스를 하나만 두고 초기화하는 함수
    void Awake()
    {
        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(gameObject);

        DontDestroyOnLoad(gameObject);

        window_show = false;
        inventory_window = GameObject.Find("item_bg");
        status_window = GameObject.Find("status_bg");
        slots = new List<GameObject>();

        foreach (GameObject slot in GameObject.FindGameObjectsWithTag("item"))
            slots.Add(slot);
        defaultImage = slots[0].GetComponent<Image>().sprite;
        current_count = 0;
        equipment_count = 0;
        consume_count = 0;
        etc_count = 0;
        inventory_window.SetActive(false);
        status_window.SetActive(false);
        

    }

    // i 버튼을 이용해 아이템창을 여는 함수
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I)) {
            if (window_show == false)
            {
                inventory_window.SetActive(true);
                status_window.SetActive(true);
                window_show = true;
            }
            else
            {
                inventory_window.SetActive(false);
                status_window.SetActive(false);
                window_show = false;
            }
        }

            if (Input.GetKeyDown(KeyCode.Z) && equipment_count > 0)
            { pop_list(equipment_count);
                equipment_count--;
            }
            if (Input.GetKeyDown(KeyCode.X) && consume_count > 0)
            { pop_list(equipment_count + consume_count);
                consume_count--;
            }
            if (Input.GetKeyDown(KeyCode.C) && etc_count > 0)
            { pop_list(equipment_count + consume_count + etc_count);
                etc_count--;
            }

        }

    //새로운 아이템을 슬롯에 넣기전에 하나씩 밀어서 공간을 확보하는 함수
    void push_list(int start)
    {
       
        for (int pos = current_count; pos >= start; pos--)
        {
            if (pos + 1 < 20)
            {
                slots[pos + 1].GetComponent<Item>().count = slots[pos].GetComponent<Item>().count;
                slots[pos + 1].GetComponent<Image>().sprite = slots[pos].GetComponent<Image>().sprite;
            }
        }

        current_count++;
    }

    //아이템을 슬롯에서 빼고나서 하나씩 끌어서 공간을 확보하는 함수
    void pop_list(int start)
    {
        int pos;
        start--;

        for (pos = start; pos <= current_count-2; pos++)
        {
            slots[pos].GetComponent<Item>().count = slots[pos + 1].GetComponent<Item>().count;
            slots[pos].GetComponent<Image>().sprite = slots[pos + 1].GetComponent<Image>().sprite;
            
        }

        slots[pos].GetComponent<Item>().count = 0;
        slots[pos].GetComponent<Image>().sprite = defaultImage;

        current_count--;
    }

    //새로운 아이템을 추가하기 위한 함수
    public void Add(GameObject item)
    {
        if (current_count >= 20)
            return;

        switch (item.tag)
        {
            case "equipment":
                push_list(equipment_count);
                slots[equipment_count].GetComponent<Item>().count = item.GetComponent<Item>().count;
                slots[equipment_count].GetComponent<Image>().sprite = item.GetComponent<Image>().sprite;
                equipment_count++;
                Destroy(item);
                break;

            case "consume":
                push_list(equipment_count + consume_count);
                slots[equipment_count + consume_count].GetComponent<Item>().count = item.GetComponent<Item>().count;
                slots[equipment_count + consume_count].GetComponent<Image>().sprite = item.GetComponent<Image>().sprite;
                consume_count++;
                Destroy(item);
                break;

            case "etc":
                push_list(equipment_count + consume_count + etc_count);
                slots[equipment_count + consume_count + etc_count].GetComponent<Item>().count = item.GetComponent<Item>().count;
                slots[equipment_count + consume_count + etc_count].GetComponent<Image>().sprite = item.GetComponent<Image>().sprite;
                etc_count++;
                Destroy(item);
                break;

        }

        Debug.Log(current_count);
    }










}

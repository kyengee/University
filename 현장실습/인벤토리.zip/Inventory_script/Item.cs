﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public int count;

    private void Awake()
    {
        
        count = Random.Range(0, 100);
    }

    private void Update()
    {
        
    }
}

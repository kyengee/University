#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUFSIZE 512

void err_quit(char *msg)
{
	fputs(msg, stderr);
	fputc('\n', stderr);
	exit(-1);
}

void err_display(char *msg)
{
	fputs(msg, stderr);
	fputc('\n', stderr);
}

int main(int argc, char* argv[])
{
	int retval;
	// socket()
	int sock=socket(PF_INET, SOCK_DGRAM, 0);
	if(sock==-1) err_quit("socket()");

	// 소켓 주소 구조체 초기화
	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family=AF_INET;
	serveraddr.sin_port=htons(atoi(argv[1]));
	serveraddr.sin_addr.s_addr=inet_addr("127.0.0.1");

	// 데이터 통신에 사용할 변수
	struct sockaddr_in peeraddr;
	int addrlen, len;
	char buf[BUFSIZE+1];

	// 서버와 데이터 통신
	while(1)
	{
		printf("\n[보낼 데이터] ");
		if(fgets(buf, BUFSIZE+1, stdin)==NULL) break;
	
		// '\n'문자 제거
		len=strlen(buf);
		if(buf[len-1]=='\n') buf[len-1]='\0';
		if(strlen(buf)==0) break;

		//데이터 보내기 
		retval=sendto(sock, buf, strlen(buf), 0, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
		if(retval==-1) { 
			err_display("sendto()");
			continue;
		}
		printf("[UDP 클라이언트] %d바이트를 보냈습니다.\n", retval);

		//데이터 받기 
		addrlen=sizeof(peeraddr);
		retval=recvfrom(sock, buf, BUFSIZE, 0, (struct sockaddr*)&peeraddr, &addrlen);
		if(retval==-1) { 
			err_display("recvfrom()");
			continue;
		}
		
		//송신자의 IP주소 체크
		if(memcmp(&peeraddr, &serveraddr, sizeof(peeraddr))) {
			printf("[오류] 잘못된 데이터입니다!\n");
			continue;
		}
		//받은 데이터 출력
		buf[retval]='\0';
		printf("[UDP 클라이언트] %d바이트를 받았습니다.\n", retval);
		printf("[받은 데이터] %s\n", buf);

	}
	close(sock);
	return 0;
}


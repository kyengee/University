# [문제1] 파일 읽고 출력하기
f1 = open("test.txt", 'w')
f1.write("Life is too short")
f1.close()

f2 = open("test.txt", 'r')
print(f2.read())

# [문제2] 파일저장
input1 = input("저장할 내용을 입력하세요: ")
f = open('test.txt', 'a')
f.write(input1)
f.close()

# [문제3] 역순 저장
with open('abc.txt', 'r') as f3:
	words = f3.readlines()
words.reverse()

with open('abc.txt', 'w') as f3:
	for word in words:
		word = word.strip()
		f3.write(word)
		f3.write('\n')

# [문제4] 파일 수정
with open('test.txt','r') as f4:
	lines = f4.readlines()
with open('test.txt','w') as f4:
	for line in lines:
		line = line.replace('java', 'python')
		f4.write(line)

# [문제5] 평균값 구하기
with open('sample.txt','r') as f5:
	nums = f5.readlines()

result = 0
for i in nums:
	result += int(i)

print('총합 : ', result)
result = result / len(nums)
print('평균 : ',result)

with open('result.txt','w') as f5:
	f5.write(str(result))



# [문제1] 홀수 짝수 판별
def is_odd(num):
	if num % 2 == 1:
		print('홀수입니다.')
	else:
		print('짝수입니다.')

# [문제2] 평균값 계산

def average(*args):
	result = 0
	for num in args:
		result += num
	result = result / len(args)
	print('평균은', result , '입니다.' )

# [문제1] 두 수의 합은?
input1 = input("첫번째 숫자를 입력하세요:")
input2 = input("두번째 숫자를 입력하세요:")

total = int(input1) + int(input2)
print("두 수의 합은 %s 입니다" % total)

# [문제2] 숫자의 총합
input_nums = input("숫자를 입력하세요:")
nums = input_nums.split(',')
num_sum = 0
for i in nums:
	num_sum += int(i)
print("총 합은 : {0} 입니다.".format(num_sum))

# [문제3] 문자열 출력
print("you" "need" "python")
print("you"+"need"+"python")
print("you", "need", "python")
print("".join(["you", "need", "python"]))
#세번째가 문자열 사이사이에 띄어쓰기가 포함된다.

# [문제4] 한줄 구구단
input_99 = input("구구단을 출력할 숫자를 입력하세요(2~9): ")
for i in range(1,10,1):
	print(i * int(input_99), end = ' ')

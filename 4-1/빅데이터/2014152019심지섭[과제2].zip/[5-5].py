# [문제2] filter와 lambda
list1 = list(filter(lambda x:x>0, [1, -2, 3, -5, 8, -3]))
print(list1)

#[문제3] 16진수를 10진수로 변환
print(int(0xea))

#[문제4] map과 lambda
list2 = list(map(lambda x:x*3, [1,2,3,4]))
print(list2)

#[문제5] 최대값과 최소값
list3 = [-8, 2, 7, 5, -3, 5, 0, 1]
result1 = max(list3) + min(list3)
print(result1)

#[문제6] 소수점 반올림
print(round(17/3, 4))

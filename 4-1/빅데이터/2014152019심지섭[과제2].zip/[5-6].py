#[문제1] sys.argv
import sys

nums = sys.argv[1:]

result = 0
for num in nums:
	result += int(num)
print(result)

#[문제2] os
import os
os.chdir('c:/doit')
result = os.popen("dir")
print(result.read())

#[문제3] glob
import glob
print(glob.glob("c:/doit/*.py"))

#[문제4] time
import time
print(time.strftime("%Y/%m/%d %H:%M:%S"))

#[문제5] random
import random
result = []

while len(result) < 6:
	num = random.randint(1, 45)
	if num not in result:
		result.append(num)
print(result)
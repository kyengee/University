#[문제1] 1부터 100까지 출력

for a in range(1,101):
	print(a)

#[문제2] 학급의 평균 점수
A = [70, 60, 55, 75, 95, 90, 80, 80, 85, 100]
Sum = 0
Average = 0
for a in A:
	Sum += a
Average = Sum / len(A)
print(Average)

#[문제3] 리스트 내포
numbers = [1, 2, 3, 4, 5]
result = []

result = [n*2 for n in numbers if n % 2 == 1]
print(result)
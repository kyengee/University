#[문제1] 문자열 나누기
pin = "881120-1068234"
print(pin[:6])
print(pin[-7:])

#[문제2] 문자열 인덱싱
pin = "881120-1068234"
print(pin[7])

#[문제3] 문자열 바꾸기1
word = "a:b:c:d"
print(word.replace(":","#"))

#[문제4] 문자열 바꾸기2
word = "a:b:c:d"
a = word.split(':')
print('#'.join(a))

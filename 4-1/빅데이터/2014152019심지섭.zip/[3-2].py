#[문제1] 3의 배수의 합
a = 1
sum = 0

while a <= 1000:
	if a%3 is 0:
		sum += a
	a += 1

print(sum)

#[문제2] 50점 이상의 총합
A = [20, 55, 67, 82, 45, 33, 90, 87, 100, 25]
count = 0
sum = 0

while count < len(A):
	if A[count] >= 50:
		sum += A[count]
	count += 1

print(sum)

#[문제3] 별 표시하기1
i = 1
while i < 5:
	print('*'*i)
	i += 1
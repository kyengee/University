#[문제1] 점수의 평균
korean = 80
english = 75
math = 55

average = (korean + english + math) / 3
print(average)
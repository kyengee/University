#[문제1] 리스트 조인
list1 = ['Life', 'is', 'too', 'short']
print(' '.join(list1))

#[문제2] 리스트 정렬
list2 = [1, 3, 5, 4, 2]
list2.sort()
list2.reverse()
print(list2)
#[문제1] 딕셔너리 만들기
dict1 = {'name':'홍길동','birth':1128,'age':30}
print(dict1)

#[문제3] 딕셔너리 값 추출
a = {'A':90, 'B':80}
print(a.get('C',70))
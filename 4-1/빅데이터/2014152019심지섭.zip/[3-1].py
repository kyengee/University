#[문제1] 조건문

a = "Life is too short, you need python"

if 'wife' in a:
	print('wife')
elif 'python' in a and 'you' not in a:
	print('python')
elif 'shirt' not in a:
	print('shirt')
elif 'need' in a:
	print('need')
else:
	print('none')